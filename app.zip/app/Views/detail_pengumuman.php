<?= $this->extend('layout/home') ?>
<?= $this->section('content') ?>
<?= $data->isi ?>
<?= $this->endSection() ?>